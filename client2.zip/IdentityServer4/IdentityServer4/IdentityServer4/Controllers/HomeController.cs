﻿using IdentityServer4.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace IdentityServer4.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
       
       
        public class LoggedInUser
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string City { get; set; }
            public string Country { get; set; }
            public string HireDate { get; set; }
            public string Cell { get; set; }
            public double? Cgpa { get; set; }
        }
        public async Task<IActionResult> Index()
        {
            if (User.Identity.IsAuthenticated)
            {
                var accessToken = await HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    using (var client = new HttpClient())
                    {
                        try
                        {
                            string url = "http://identity.colaraz.net/localapi";
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                            HttpResponseMessage response = await client.GetAsync(url);
                            var jsonString = await response.Content.ReadAsStringAsync();
                            List<LoggedInUser> LoggedInUser = JsonConvert.DeserializeObject<List<LoggedInUser>>(jsonString);
                            if (LoggedInUser.Count > 0)
                            {
                                ViewBag.UserInformation = LoggedInUser[0];
                            }
                        }
                        catch (Exception)
                        {
                            return RedirectToAction("Logout");
                        }
                    }
                }
            }

            return View();
        }
        public  IActionResult Claims()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [Authorize]
        public IActionResult Login()
        {
            return RedirectToAction("Index");
        }
        public IActionResult Logout()
        {
            return SignOut("Cookies", "oidc");
        }

       
    }
}
