﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MvcClient.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace MvcClient.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        //public async Task<IActionResult> Index()
        //{

        //    //var accessToken = await HttpContext.GetTokenAsync("access_token");

        //    //var handler = new JwtSecurityTokenHandler();
        //    //var token = handler.ReadJwtToken(accessToken);
        //    //ViewBag.token = token;

        //    // var accessToken = await HttpContext.GetTokenAsync("access_token");

        //    // var client = new HttpClient();
        //    // client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
        //    // var content = await client.GetStringAsync("http://localhost:5050/LocalApi");
        //    //var ob  = JsonConvert.DeserializeObject<dynamic>(content);
        //    // ViewBag.ob = ob;
        //    // string email = ob.Email;
        //    return View();
        //}
        public async Task<IActionResult> Index()
        {
            if (User.Identity.IsAuthenticated)
            {
                var accessToken = await HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    using (var client = new HttpClient())
                    {
                        try
                        {
                            string url = "http://identity.colaraz.net/localapi";
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                            HttpResponseMessage response = await client.GetAsync(url);
                            var jsonString = await response.Content.ReadAsStringAsync();
                            List<LoggedInUser> LoggedInUser = JsonConvert.DeserializeObject<List<LoggedInUser>>(jsonString);
                            if (LoggedInUser.Count > 0)
                            {
                                ViewBag.UserInformation = LoggedInUser[0];
                            }
                        }
                        catch (Exception ex)
                        {
                            return RedirectToAction("Logout");
                        }
                    }
                }
            }

            return View();
        }
        public async Task<IActionResult> MyView()
        {
           
            return View();
        }

        public async Task<IActionResult> CallApi()
        {
            var accessToken = await HttpContext.GetTokenAsync("access_token");

            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            var content = await client.GetStringAsync("http://localhost:5001/identity");

            ViewBag.Json = JArray.Parse(content).ToString();
            return View("json");
        }

        public IActionResult Logout()
        {
            return SignOut("Cookies", "oidc");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
    public class LoggedInUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string HireDate { get; set; }
        public string Cell { get; set; }
        public double? Cgpa { get; set; }
    }
}