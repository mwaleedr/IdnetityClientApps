﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MvcClient.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace MvcClient.Controllers
{
    [AllowAnonymous]
    public class LogInController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public LogInController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(string Username, string Password)
        {
            var dict = new Dictionary<string, string>();
            dict.Add("client_Id", "ro.client");
            dict.Add("client_secret", "secret");
            dict.Add("grant_type", "password");

            dict.Add("username", "alice");
            dict.Add("password", "alice");
            var client = new HttpClient();
            var req = new HttpRequestMessage(HttpMethod.Post, "http://localhost:5000/connect/token") { Content = new FormUrlEncodedContent(dict) };
            var res = await client.SendAsync(req);
            var responseContent = (res.IsSuccessStatusCode) ? await
                      res.Content.ReadAsStringAsync() : null;
            ViewBag.Data = JsonConvert.DeserializeObject<dynamic>(responseContent); 
            return View();
        }


       

      

       
    }
}